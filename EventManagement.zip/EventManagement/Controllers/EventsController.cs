﻿using Microsoft.AspNetCore.Mvc;
using EventManagement.Data;
using EventManagement.Models;
using EventManagement.Dtos;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;

namespace EventManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventsController : ControllerBase
    {
        private readonly EventsDbContext _context;

        public EventsController(EventsDbContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Create new event
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> CreateEvent(EventCreateDto dto)
        {
            var newEvent = new Event
            {
                Name = dto.Name,
                Location = dto.Location,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                MaxRegistrations = dto.MaxRegistrations
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync(); // <--- THIS MUST EXIST

            return Ok(newEvent);
        }


        /// <summary>
        /// Get Event Users.
        /// </summary>
        [HttpGet("{id}/registration")]
        
        public IActionResult GetEventRegistrations(int id)
        {
            var eventWithUsers = _context.Events
                    .Include(e => e.EventUsers)
                        .ThenInclude(eu => eu.User)
                    .Where(e => e.Id == id)
                    .Select(e => new
                    {
                         e.Id,
                         e.Name,
                        RegisteredUsers = e.EventUsers.Select(eu => new
                        {               
                            eu.UserRef,
                            eu.User.Name,
                            eu.User.DateOfBirth
                        })
                    }).FirstOrDefault();


            if (eventWithUsers == null) return NotFound("Event not found");
            return Ok(eventWithUsers);
        }

        /// <summary>
        /// Register user to event
        /// </summary>    
        [HttpPost("{id}/registration")]
        public async Task<IActionResult> RegisterToEventAsync(int id, [FromBody] int userId)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == userId);
            var ev = _context.Events.FirstOrDefault(e => e.Id == id);

            if (user == null || ev == null)
                return NotFound("User or Event not found");

            var alreadyRegistered = _context.EventUsers.Any(eu => eu.EventRef == id && eu.UserRef == userId);
            if (alreadyRegistered)
                return BadRequest("User already registered");

            if (ev.MaxRegistrations <= 0)
                return BadRequest("Event is full");

            var eventUser = new EventUser
            {
                EventRef = id,
                UserRef = userId,
                Creation = DateTime.Now
            };

            ev.MaxRegistrations -= 1;
            _context.EventUsers.Add(eventUser);
            await _context.SaveChangesAsync();

            return Ok(new { message = "User registered", remainingSlots = ev.MaxRegistrations });
        }



        /// <summary>
        /// Get event by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEventById(int id)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return NotFound();

            var dto = new EventReadDto
            {
                Id = ev.Id,
                Name = ev.Name,
                Location = ev.Location,
                DateTime = ev.StartDate
            };

            return Ok(dto);
        }


        /// <summary>
        /// Update an existing event
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, EventCreateDto dto)
        {
            var existing = await _context.Events.FindAsync(id);
            if (existing == null) return NotFound();

            existing.Name = dto.Name;
            existing.Location = dto.Location;
            existing.StartDate = dto.StartDate;
            existing.EndDate = dto.EndDate;
            existing.MaxRegistrations = dto.MaxRegistrations;

            await _context.SaveChangesAsync();
            return Ok(existing);
        }


        /// <summary>
        /// Delete an existing event
        /// </summary>
        [HttpDelete("{id}")]
        public IActionResult DeleteEvent(int id)
        {
            var ev = _context.Events.Find(id);
            if (ev == null) return NotFound();

            _context.Events.Remove(ev);
            _context.SaveChanges();
            return Ok("Deleted");
        }

        /// <summary>
        /// Get events schedule
        /// </summary>
        [HttpGet("/schedule")]
        public async Task<IActionResult> GetSchedule()
        {
            var events = await _context.Events
                .Select(e => new {
                    e.Id,
                    e.Name,
                    e.Location,
                    StartTime = e.StartDate,
                    EndTime = e.EndDate,
                    MaxRegistrations = e.MaxRegistrations // ← this must be here
                })
                .ToListAsync();

            return Ok(events);
        }


        /// <summary>
        /// Get the event weather
        /// </summary>
        [HttpGet("{id}/weather")]
        public async Task<IActionResult> GetEventWeather(int id, [FromServices] IMemoryCache cache)
        {
            var ev = _context.Events.Find(id);
            if (ev == null) return NotFound();

            var city = ev.Location;
            if (cache.TryGetValue(city, out object cachedWeather))
                return Ok(cachedWeather);

            using var client = new HttpClient();
            var response = await client.GetAsync($"https://api.openweathermap.org/data/2.5/weather?q={city}&appid=cb4169250b44e87579b7829b1bc3b134&units=metric");
            if (!response.IsSuccessStatusCode) return BadRequest("Weather fetch failed");

            var content = await response.Content.ReadAsStringAsync();
            var json = JsonSerializer.Deserialize<JsonElement>(content);

            var result = new
            {
                city,
                temp = json.GetProperty("main").GetProperty("temp").GetDouble(),
                desc = json.GetProperty("weather")[0].GetProperty("description").GetString()
            };

            cache.Set(city, result, TimeSpan.FromMinutes(1));
            return Ok(result);
        }


    }
}
