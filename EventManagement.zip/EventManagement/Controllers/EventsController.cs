﻿using Microsoft.AspNetCore.Mvc;
using EventManagement.Data;
using EventManagement.Models;
using EventManagement.Dtos;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;

namespace EventManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventsController : ControllerBase
    {
        private readonly EventsDbContext _context;

        public EventsController(EventsDbContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Create new event
        /// </summary>
        [HttpPost]
        public IActionResult CreateEvent([FromBody] EventCreateDto dto)
        {
            var newEvent = new Event
            {
                Name = dto.Name,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                MaxRegistrations = dto.MaxRegistrations,
                Location = dto.Location
            };

            _context.Events.Add(newEvent);
            _context.SaveChanges();
            return Ok(newEvent);
        }

        /// <summary>
        /// Get Event Users.
        /// </summary>
        [HttpGet("{id}/registration")]
        
        public IActionResult GetEventRegistrations(int id)
        {
            var eventWithUsers = _context.Events
                    .Include(e => e.EventUsers)
                        .ThenInclude(eu => eu.User)
                    .Where(e => e.Id == id)
                    .Select(e => new
                    {
                         e.Id,
                         e.Name,
                        RegisteredUsers = e.EventUsers.Select(eu => new
                        {               
                            eu.UserRef,
                            eu.User.Name,
                            eu.User.DateOfBirth
                        })
                    }).FirstOrDefault();


            if (eventWithUsers == null) return NotFound("Event not found");
            return Ok(eventWithUsers);
        }

        /// <summary>
        /// Register user to event
        /// </summary>    
        [HttpPost("{id}/registration")]
        public IActionResult RegisterToEvent(int id, [FromBody] int userId)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == userId);
            var ev = _context.Events.FirstOrDefault(e => e.Id == id);

            if (user == null || ev == null)
                return NotFound("User or Event not found");

            var alreadyRegistered = _context.EventUsers
                .Any(eu => eu.EventRef == id && eu.UserRef == userId);
            if (alreadyRegistered)
                return BadRequest("User already registered");

            // Correct way to add to the EventUser table
            var eventUser = new EventUser
            {
                EventRef = id,
                UserRef = userId,
                Creation = DateTime.Now
            };

            _context.EventUsers.Add(eventUser);
            _context.SaveChanges();

            return Ok("User registered successfully");
        }


        /// <summary>
        /// Get event by ID
        /// </summary>
        [HttpGet("{id}")]
        public IActionResult GetEvent(int id)
        {
            var ev = _context.Events.Find(id);
            if (ev == null) return NotFound();
            return Ok(ev);
        }

        /// <summary>
        /// Update an existing event
        /// </summary>
        [HttpPut("{id}")]
        public IActionResult UpdateEvent(int id, [FromBody] EventCreateDto updated)
        {
            var ev = _context.Events.Find(id);
            if (ev == null) return NotFound();

            ev.Name = updated.Name;
            ev.StartDate = updated.StartDate;
            ev.EndDate = updated.EndDate;
            ev.MaxRegistrations = updated.MaxRegistrations;
            ev.Location = updated.Location;

            _context.SaveChanges();
            return Ok(ev);
        }

        /// <summary>
        /// Delete an existing event
        /// </summary>
        [HttpDelete("{id}")]
        public IActionResult DeleteEvent(int id)
        {
            var ev = _context.Events.Find(id);
            if (ev == null) return NotFound();

            _context.Events.Remove(ev);
            _context.SaveChanges();
            return Ok("Deleted");
        }

        /// <summary>
        /// Get events schedule
        /// </summary>
        [HttpGet("/schedule")]
        public IActionResult GetSchedule()
        {
            var events = _context.Events
                .Select(e => new {
                    e.Id,
                    e.Name,
                    e.StartDate,
                    e.EndDate
                }).ToList();

            return Ok(events);
        }

        /// <summary>
        /// Get the event weather
        /// </summary>
        [HttpGet("{id}/weather")]
        public async Task<IActionResult> GetEventWeather(int id, [FromServices] IMemoryCache cache)
        {
            var ev = _context.Events.Find(id);
            if (ev == null) return NotFound();

            var city = ev.Location;
            if (cache.TryGetValue(city, out object cachedWeather))
                return Ok(cachedWeather);

            using var client = new HttpClient();
            var response = await client.GetAsync($"https://api.openweathermap.org/data/2.5/weather?q={city}&appid=cb4169250b44e87579b7829b1bc3b134&units=metric");
            if (!response.IsSuccessStatusCode) return BadRequest("Weather fetch failed");

            var content = await response.Content.ReadAsStringAsync();
            var json = JsonSerializer.Deserialize<JsonElement>(content);

            var result = new
            {
                city,
                temp = json.GetProperty("main").GetProperty("temp").GetDouble(),
                desc = json.GetProperty("weather")[0].GetProperty("description").GetString()
            };

            cache.Set(city, result, TimeSpan.FromMinutes(1));
            return Ok(result);
        }


    }
}
