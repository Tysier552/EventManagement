USE Events;
GO
-- Insert Users
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 1', '2012-08-16');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 2', '1994-10-25');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 3', '2009-04-22');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 4', '2000-02-06');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 5', '2002-01-17');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 6', '2013-09-13');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 7', '1992-05-21');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 8', '1991-09-25');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 9', '1990-06-19');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 10', '1996-06-16');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 11', '2003-03-30');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 12', '2017-02-09');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 13', '2015-05-28');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 14', '2009-07-19');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 15', '2003-11-17');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 16', '2001-12-23');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 17', '1991-09-15');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 18', '2000-11-10');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 19', '2012-07-28');
INSERT INTO Users (Name, DateOfBirth) VALUES ('User 20', '1991-02-24');

-- Insert Events
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 1', '2025-07-04 00:00:00', '2025-07-06 00:00:00', 100, 'Haifa');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 2', '2025-07-07 00:00:00', '2025-07-09 00:00:00', 200, 'Tel Aviv');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 3', '2025-07-10 00:00:00', '2025-07-12 00:00:00', 50, 'Jerusalem');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 4', '2025-07-13 00:00:00', '2025-07-15 00:00:00', 50, 'Jerusalem');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 5', '2025-07-16 00:00:00', '2025-07-18 00:00:00', 150, 'Tel Aviv');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 6', '2025-07-19 00:00:00', '2025-07-21 00:00:00', 200, 'Jerusalem');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 7', '2025-07-22 00:00:00', '2025-07-24 00:00:00', 50, 'Tel Aviv');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 8', '2025-07-25 00:00:00', '2025-07-27 00:00:00', 100, 'Haifa');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 9', '2025-07-28 00:00:00', '2025-07-30 00:00:00', 200, 'Tel Aviv');
INSERT INTO Events (Name, StartDate, EndDate, MaxRegistrations, Location) VALUES ('Event 10', '2025-07-31 00:00:00', '2025-08-02 00:00:00', 100, 'Jerusalem');

-- Insert Event Registrations
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (5, 15, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (6, 2, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (5, 5, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (1, 14, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (7, 13, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (8, 10, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (8, 19, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (3, 3, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (5, 16, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (2, 12, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (9, 8, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (6, 19, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (8, 15, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (8, 5, GETDATE());
INSERT INTO EventUser (EventRef, UserRef, Creation) VALUES (7, 8, GETDATE());