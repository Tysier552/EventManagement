﻿const API_BASE = "/api/Events";


// Create Event and Update Event 
document.getElementById("eventForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const id = document.getElementById("eventId").value;
    const name = document.getElementById("name").value;
    const location = document.getElementById("location").value;
    const start = document.getElementById("start").value;
    const end = document.getElementById("end").value;
    const max = parseInt(document.getElementById("max").value);

    const now = new Date();
    const startDate = new Date(start);
    const endDate = new Date(end);

    if (startDate < now) {
        alert("Start time cannot be in the past.");
        return;
    }

    if (endDate < startDate) {
        alert("End time cannot be before start time.");
        return;
    }

    const eventData = {
        name,
        location,
        startDate: start,
        endDate: end,
        maxRegistrations: max
    };

    if (id) {
        await fetch(`${API_BASE}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(eventData)
        });
        alert("Event updated!");
    } else {
        await fetch(API_BASE, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(eventData)
        });
        alert("Event created!");
    }

    e.target.reset();
    document.getElementById("submitButton").innerText = "Create Event";
    await loadEvents();
});


// Register User to Event and update Max Registration number accordingly.

document.getElementById("registerForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const eventId = document.getElementById("regEventId").value;
    const userName = document.getElementById("userName").value;

    // Step 1: Get user by name
    const userResp = await fetch(`/api/Users/name/${encodeURIComponent(userName)}`);

    if (!userResp.ok) {
        alert("User not found. Please check the name.");
        return;
    }

    const user = await userResp.json();

    // Step 2: Register user to event (send raw ID)
    const regResp = await fetch(`/api/Events/${eventId}/registration`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user.id)
    });

    const result = await regResp.json();

    if (!regResp.ok) {
        alert(result); // e.g., "User already registered"
        return;
    }

    alert(result.message + ` (Remaining slots: ${result.remainingSlots})`);
    await loadEvents();
    document.getElementById("registerForm").reset();
});



function cancelEdit() {
    document.getElementById("eventForm").reset();
    document.getElementById("eventId").value = "";
    document.getElementById("submitButton").innerText = "Create Event";
}

async function loadEvents() {
    console.log("Refreshing events...");
    const tbody = document.querySelector("#eventsTable tbody");
    tbody.innerHTML = "";

    const response = await fetch("/schedule");
    const events = await response.json();

    events.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));

    events.forEach(ev => {
        const start = ev.startTime ? new Date(ev.startTime).toLocaleString() : "N/A";
        const end = ev.endTime ? new Date(ev.endTime).toLocaleString() : "N/A";

        const tr = document.createElement("tr");
        tr.innerHTML = `
      <td>${ev.id}</td>
      <td>${ev.name}</td>
      <td>${ev.location ?? 'N/A'}</td>
      <td>${start} - ${end}</td>
      <td>${ev.maxRegistrations}</td>
      <td>
        <button onclick="editEvent(${ev.id})">Edit</button>
        <button onclick="deleteEvent(${ev.id})">Delete</button>
        <button onclick="showMap('${ev.location}')">Map</button>
      </td>
    `;
        tbody.appendChild(tr);
    });
}

async function deleteEvent(id) {
    await fetch(`${API_BASE}/${id}`, { method: "DELETE" });
    await loadEvents();
}

async function editEvent(id) {
    const response = await fetch(`${API_BASE}/${id}`);
    const ev = await response.json();

    document.getElementById("eventId").value = ev.id;
    document.getElementById("name").value = ev.name;
    document.getElementById("location").value = ev.location;
    document.getElementById("start").value = ev.startDate || ev.startTime;
    document.getElementById("end").value = ev.endDate || ev.endTime;
    document.getElementById("max").value = ev.maxRegistrations;

    document.getElementById("submitButton").innerText = "Update Event";
}

function showMap(location) {
    const query = encodeURIComponent(location);
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, "_blank");
}

// Initial load
loadEvents();

const startInput = document.getElementById("start");
const endInput = document.getElementById("end");

function getLocalISOString(datetime = new Date()) {
    datetime.setMinutes(datetime.getMinutes() - datetime.getTimezoneOffset());
    return datetime.toISOString().slice(0, 16); // 'YYYY-MM-DDTHH:MM'
}

// Set current time as minimum when start field gets focus
startInput.addEventListener("focus", () => {
    startInput.min = getLocalISOString();
});

// When start is picked, end cannot be before it
startInput.addEventListener("input", () => {
    endInput.min = startInput.value;
});
