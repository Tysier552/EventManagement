﻿namespace EventManagement.Dtos
{
    public class UserCreateDto
    {
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
}
