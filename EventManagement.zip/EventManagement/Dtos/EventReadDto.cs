﻿namespace EventManagement.Dtos
{
    public class EventReadDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public DateTime DateTime { get; set; }

        public string GoogleMapsUrl
        {
            get
            {
                return $"https://www.google.com/maps/search/?api=1&query={Uri.EscapeDataString(Location)}";
            }
        }
    }
}
