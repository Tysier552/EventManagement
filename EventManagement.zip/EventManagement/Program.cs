using EventManagement.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddMemoryCache();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    c.IncludeXmlComments(xmlPath);
});
builder.Services.AddDbContext<EventsDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

void LoadSeedData()
{
    using (var scope = app.Services.CreateScope())
    {
        var db = scope.ServiceProvider.GetRequiredService<EventsDbContext>();
        db.Database.EnsureDeleted();   //  Drops the DB
        db.Database.EnsureCreated();  //  Recreates schema from models
    }
    string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

    string seedScript = File.ReadAllText("SQL Script/SeedData.sql");

    // Split the script into individual commands using "GO"
    var commands = seedScript
        .Split(new[] { "GO", "go", "Go", "gO" }, StringSplitOptions.RemoveEmptyEntries);

    using var connection = new SqlConnection(connectionString);
    connection.Open();

    foreach (var cmd in commands)
    {
        using var command = new SqlCommand(cmd, connection);
        command.ExecuteNonQuery();
    }
}


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();

}

app.UseHttpsRedirection();

app.UseStaticFiles(); 

app.UseAuthorization();

app.MapControllers();

LoadSeedData();

app.Run();