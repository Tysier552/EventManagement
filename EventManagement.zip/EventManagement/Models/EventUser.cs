﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace EventManagement.Models
{
    [Table("EventUser")] // 
    public class EventUser
    {
        public int EventRef { get; set; }
        public int UserRef { get; set; }

        public DateTime Creation { get; set; } = DateTime.Now;

        [JsonIgnore]
        public Event Event { get; set; }

        public User User { get; set; }
    }
}
