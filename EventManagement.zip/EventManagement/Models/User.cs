﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EventManagement.Models
{
    public class User
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public DateTime DateOfBirth { get; set; }

        [JsonIgnore] // 👈
        public ICollection<EventUser> EventUsers { get; set; }
    }
}
